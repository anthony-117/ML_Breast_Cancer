library(tidyverse)
library(caret)

sigmoid <- function(x){
  return(1/(1 + exp(-x)))
}

sigmoid.derivative <- function(x){
  sig <- sigmoid(x)
  return(sig * (1 - sig))
}

activation.fn <- function(x){
  return(sigmoid(x))
}
activation.dfn <- function(x){
  return(sigmoid.derivative(x))
}

cost <- function(error){
  return(0.5 * colSums(error^2) )
}

# .p stands for plus 1 layer
dirac.hidden <- function(z.l, dirac.p, weight.p){
  
  weight.nobias <- weight.p[-1, , drop = FALSE]
  
  # Matrix multiplication followed by element-wise multiplication
  dirac <- (dirac.p %*% t(weight.nobias)) * activation.dfn(z.l)
  
  return(as.matrix(dirac))
}



NN <-function(X, Y.d, hidden_layers){
  
  layers <- c(ncol(X), hidden_layers, ncol(Y.d))
  
  weights <- initialize_weights(layers)
  
  NN <- list(
    layers = layers,
    weights = weights
  )
  return(NN)
  
}
initialize_weights <- function(layers) {
  weights = list()
  
  # Loop over layers to initialize weights
  for (i in 1:(length(layers) - 1)) {
    # Random weights between layers[i] and layers[i+1]
    weights[[i]] <- matrix(runif((layers[i] +1) * layers[i+1], min=-0.5, max=0.5), nrow=layers[i] +1, ncol=layers[i+1])
    # Set first row to fixed value 0.5
    weights[[i]][1,] <- 0.5
  }
  return(weights)
}



feed_forward <- function(NN, X.train){
  y.fw <- list()
  z.fw <- list()
  
  y <- X.train
  y.fw[[1]] <- y  # Store the input layer activation
  
  for(l in 1:length(NN$weights)){
    # add the -1 neuron 
    y.p <- as.matrix(cbind(-1, y))
    
    z.l <- y.p %*% NN$weights[[l]]
    z.fw[[l]] <- z.l
    
    y.l <- activation.fn(z.l)
    
    y.fw[[l+1]] <- y.l
    
    y <- y.l
  }
  
  return(list(
    y.fw = y.fw,  
    z.fw = z.fw   
  ))
}



back_propagation <- function(NN, z.fw,Y.train){
  dirac <- list()
  weight.nb <- length(NN$weights)
  
  z.L <- z.fw[[length(z.fw)]]
  error <- Y.train - activation.fn(z.L)
  
  # element wise multiplication
  dirac.L <- error * activation.dfn(z.L)
  
  dirac[[weight.nb]] <- as.matrix(dirac.L)
  
  # Dirac of hidden layers
  for(l in (weight.nb-1):1){
    dirac[[l]] <- dirac.hidden(z.fw[[l]], dirac[[l+1]], NN$weights[[l+1]] )
  } 
  return(dirac)
  
}


output.classify <- function(output){
  # Using 0.1 as threshold for binary classification
  predicted_labels <- ifelse(output > 0.1, 1, 0)  
  return(predicted_labels)
}

NN.train <- function(NN, X, Y, epochs, learning_rate, momentum, verbose = TRUE) {
  
  cost_history <- numeric(epochs)
  # test_cost_history <- numeric(epochs)
  confusion_matrices <- data.frame(Epoch = integer(), TP = integer(), FP = integer(), FN = integer(), TN = integer())
  
  old_weight <- NN$weights
  percent <- 0.8
  
  accuracy_history <- numeric(epochs)
  train_accuracy <- numeric(epochs)
  precision_history <- numeric(epochs)
  recall_history <- numeric(epochs)
  f1_history <- numeric(epochs)
  
  for (epoch in 1:epochs) {
    indices <- sample(1:nrow(X), size = percent * nrow(X))
    
    X.train <- X[indices, ]
    Y.train <- Y[indices, ]
    X.test <- X[-indices, ]
    Y.test <- Y[-indices, ]
    
    # Forward propagation
    forward_result <- feed_forward(NN, X.train)
    y.fw <- forward_result$y.fw
    z.fw <- forward_result$z.fw
    output <- y.fw[[length(y.fw)]]
    
    # Compute cost
    error <- Y.train - output
    current_cost <- cost(error)
    
    predicted_labels <- output.classify(output)
    actual_labels <- Y.train
    cm <- table(Predicted = factor(predicted_labels, levels = c(1, 0)), 
                Actual = factor(actual_labels, levels = c(1, 0)))
    
    metrics <- calculate_metrics(cm)
    train_accuracy[epoch] <- metrics$accuracy
      
    cost_history[epoch] <- current_cost
    
    # Backpropagation
    dirac <- back_propagation(NN, z.fw, Y.train)
    
    # Update weights
    for (l in 1:length(NN$weights)) {
      a <- cbind(-1,y.fw[[l]])
      weight.delta <- learning_rate * (t(a) %*% dirac[[l]]) + 
        momentum * (NN$weights[[l]] - old_weight[[l]])
      
      old_weight[[l]] <- NN$weights[[l]]
      NN$weights[[l]] <- NN$weights[[l]] + weight.delta
    }
    
    
    # Compute confusion matrix
    predicted_labels <- NN.predict(NN, X.test)
    actual_labels <- Y.test
    cm <- table(Predicted = factor(predicted_labels, levels = c(1, 0)), 
                Actual = factor(actual_labels, levels = c(1, 0)))
    
    
    # Compute metrics
    metrics <- calculate_metrics(cm)
    accuracy_history[epoch] <- metrics$accuracy
    precision_history[epoch] <- metrics$precision
    recall_history[epoch] <- metrics$recall
    f1_history[epoch] <- metrics$f1_score
    
    if (verbose && epoch %% 100 == 0) {
      cat("Epoch:", epoch, "Cost:", current_cost, 
          "Accuracy:", round(metrics$accuracy, 4),
          "Precision:", round(metrics$precision, 4), "\n")
    }
  }
  
  # Store evaluation data separately
  training_data <- list(
    cost_history = cost_history,
    accuracy_history = accuracy_history,
    train_accuracy = train_accuracy,
    precision_history = precision_history,
    recall_history = recall_history,
    f1_history = f1_history
  )
  
  return(list(NN = NN, training_data = training_data))
}


NN.predict <- function(NN, X) {
  
  y <- as.matrix(X)
  
  for (l in 1:length(NN$weights)) {
    y.p <- cbind(-1, y)
    z.l <- y.p %*% NN$weights[[l]]
    y <- activation.fn(z.l)
  }
  y <- output.classify(y)
  return(y)
}

NN.train_multiple.lr <- function(NN, X, Y, epochs, learning_rates, momentum, verbose = TRUE) {
  training_results <- list()
  
  for (lr in learning_rates) {
    cat("Training with learning rate:", lr, "\n")
    result <- NN.train(NN, X, Y, epochs, lr, momentum, verbose)
    training_results[[as.character(lr)]] <- result$training_data
  }
  
  return(training_results)
}


NN.train_multiple.momentum <- function(NN, X, Y, epochs, learning_rate, momentums, verbose = TRUE) {
  training_results <- list()
  
  for (m in momentums) {
    cat("Training with learning rate:", m, "\n")
    result <- NN.train(NN, X, Y, epochs, learning_rate, m, verbose)
    training_results[[as.character(m)]] <- result$training_data
  }
  
  return(training_results)
}


# Function to calculate evaluation metrics
calculate_metrics <- function(confusion_matrix) {
  # Extract values from confusion matrix
  TP <- confusion_matrix[2, 2]  # True Positives
  TN <- confusion_matrix[1, 1]  # True Negatives
  FP <- confusion_matrix[2, 1]  # False Positives
  FN <- confusion_matrix[1, 2]  # False Negatives
  
  # Handle potential division by zero
  accuracy <- (TP + TN) / sum(confusion_matrix)
  
  precision <- ifelse(TP + FP > 0, TP / (TP + FP), 0)
  
  recall <- ifelse(TP + FN > 0, TP / (TP + FN), 0)
  
  f1_score <- ifelse(precision + recall > 0, 2 * precision * recall / (precision + recall), 0)
  
  return(list(
    accuracy = accuracy,
    precision = precision,
    recall = recall,
    f1_score = f1_score
  ))
}

plot_confusion_matrix <- function(NN, X, Y) {
  # Get predictions from the neural network
  predictions <- NN.predict(NN, X)
  
  pred_vector <- as.vector(predictions)
  actual_vector <- as.vector(as.integer(Y[[1]]))
  
  # Create confusion matrix with factors having levels in the desired order (1 first, then 0)
  cm <- table(Predicted = factor(pred_vector, levels = c(1, 0)), 
              Actual = factor(actual_vector, levels = c(1, 0)))
  
  # Change the labels to 'M' and 'B'
  new_labels <- c("M", "B")
  colnames(cm) <- new_labels[match(colnames(cm), c("1", "0"))]
  rownames(cm) <- new_labels[match(rownames(cm), c("1", "0"))]
  
  # Extract metrics (now using updated labels)
  TP <- if ("M" %in% rownames(cm) && "M" %in% colnames(cm)) cm["M", "M"] else 0
  FP <- if ("M" %in% rownames(cm) && "B" %in% colnames(cm)) cm["M", "B"] else 0
  FN <- if ("B" %in% rownames(cm) && "M" %in% colnames(cm)) cm["B", "M"] else 0
  TN <- if ("B" %in% rownames(cm) && "B" %in% colnames(cm)) cm["B", "B"] else 0
  
  # Calculate performance metrics
  accuracy <- (TP + TN) / (TP + TN + FP + FN)
  precision <- ifelse(TP + FP > 0, TP / (TP + FP), 0)
  recall <- ifelse(TP + FN > 0, TP / (TP + FN), 0)
  f1_score <- ifelse(precision + recall > 0, 2 * precision * recall / (precision + recall), 0)
  
  # Create a data frame for ggplot2
  cm_df <- as.data.frame(as.table(cm))
  names(cm_df) <- c("Prediction", "Observed", "Freq")
  
  # Make sure the order is preserved in the plot
  cm_df$Prediction <- factor(cm_df$Prediction, levels = c("M", "B"))
  cm_df$Observed <- factor(cm_df$Observed, levels = c("M", "B"))
  
  # Create the heatmap using ggplot2
  library(ggplot2)
  
  p <- ggplot(cm_df, aes(x = Observed, y = Prediction, fill = Freq)) +
    geom_tile(color = "white") +
    geom_text(aes(label = Freq), color = "black", size = 8) +
    scale_fill_gradient(low = "#c1ff2e", high = "#25188c") +
    labs(title = "Confusion matrix", x = "Observed", y = "Prediction") +
    theme_minimal() +
    theme(
      axis.text = element_text(size = 12),
      axis.title = element_text(size = 14),
      plot.title = element_text(size = 16, hjust = 0.5),
      legend.title = element_text(size = 12),
      legend.text = element_text(size = 10)
    )
  
  # Print metrics
  cat("Accuracy:", round(accuracy, 4), "\n")
  cat("Precision:", round(precision, 4), "\n")
  cat("Recall:", round(recall, 4), "\n")
  cat("F1 Score:", round(f1_score, 4), "\n")
  
  # Return both the confusion matrix, metrics, and the plot
  return(list(
    confusion_matrix = cm,
    metrics = list(
      accuracy = accuracy,
      precision = precision,
      recall = recall,
      f1_score = f1_score
    ),
    plot = p
  ))
}